search <<<
search >>>
search #define TRACEDLL 1

-----------

make test
make test2
make debug
